namespace TerminoApp.Models;

public class UnavailableDay
{
    public int Id { get; set; }
    public int AdminId { get; set; }
    public DateTime Date { get; set; }
}