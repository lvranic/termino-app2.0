namespace TerminoApp.Models;

public class Reservation
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int ServiceId { get; set; }
    public DateTime Date { get; set; }
    public string Hour { get; set; } = default!;
    public string Time { get; set; } = default!;
    public int DurationMinutes { get; set; }
}