using TerminoApp.Data;
using TerminoApp.Models;
using TerminoApp.GraphQL.Inputs;
using HotChocolate;
using HotChocolate.Data;

public class Mutation
{
    [UseDbContext(typeof(AppDbContext))]
    public async Task<User> AddUser(UserInput input, [Service(ServiceKind.Pooled)] AppDbContext context)
    {
        var user = new User
        {
            Name = input.Name,
            Email = input.Email,
            Phone = input.Phone,
            Role = input.Role
        };

        context.Users.Add(user);
        await context.SaveChangesAsync();
        return user;
    }
}


    [UseDbContext(typeof(AppDbContext))]
    public async Task<Service> AddService(ServiceInput input, [Service(ServiceKind.Pooled)] AppDbContext context)
    {
        var service = new Service
        {
            Name = input.Name,
            Description = input.Description,
            Address = input.Address,
            WorkingHours = input.WorkingHours,
            AdminId = input.AdminId
        };

        context.Services.Add(service);
        await context.SaveChangesAsync();
        return service;
    }

    [UseDbContext(typeof(AppDbContext))]
    public async Task<Reservation> AddReservation(ReservationInput input, [Service(ServiceKind.Pooled)] AppDbContext context)
    {
        var reservation = new Reservation
        {
            UserId = input.UserId,
            ServiceId = input.ServiceId,
            Date = input.Date,
            Hour = input.Hour,
            Time = input.Time,
            DurationMinutes = input.DurationMinutes
        };

        context.Reservations.Add(reservation);
        await context.SaveChangesAsync();
        return reservation;
    }

    [UseDbContext(typeof(AppDbContext))]
    public async Task<UnavailableDay> AddUnavailableDay(UnavailableDayInput input, [Service(ServiceKind.Pooled)] AppDbContext context)
    {
        var day = new UnavailableDay
        {
            AdminId = input.AdminId,
            Date = input.Date
        };

        context.UnavailableDays.Add(day);
        await context.SaveChangesAsync();
        return day;
    }
