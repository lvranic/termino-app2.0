namespace TerminoApp.GraphQL.Inputs;

public class UnavailableDayInput
{
    public int AdminId { get; set; }
    public DateTime Date { get; set; }
}