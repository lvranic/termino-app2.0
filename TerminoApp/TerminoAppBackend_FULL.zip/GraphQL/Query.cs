using TerminoApp.Data;
using TerminoApp.Models;
using Microsoft.EntityFrameworkCore;

public class Query
{
    public async Task<User?> Login(string email, [Service] AppDbContext context)
    {
        return await context.Users.FirstOrDefaultAsync(u => u.Email == email);
    }
}
