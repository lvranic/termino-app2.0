using Microsoft.EntityFrameworkCore;
using TerminoApp.Data;
using TerminoApp.GraphQL;
using TerminoApp.GraphQL.Inputs;
using HotChocolate.Types;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddPooledDbContextFactory<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services
    .AddGraphQLServer()
    .AddQueryType<Query>()
    .AddMutationType<Mutation>()
    .AddType<InputObjectType<UserInput>>()
    .AddFiltering()
    .AddSorting();

var app = builder.Build();
app.MapGraphQL("/graphql");
app.Run();
